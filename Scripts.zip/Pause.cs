﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pause : MonoBehaviour
{
    public GameObject pausePanel;
    void Start()
    {
        pausePanel = GetComponent<GameObject>();
    }

    public void Init()
    {
        pausePanel.SetActive(true);
    }

    public void Terminate()
    {
        pausePanel.SetActive(false);
    }

    // Update is called once per frame
    void Update () {
		
	}
}
