﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class Send : MonoBehaviour, IPointerDownHandler
{
    public GameObject target;
    public string methodName;

    public void OnPointerDown(PointerEventData eventData)
    {
        target.SendMessage(methodName);
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
