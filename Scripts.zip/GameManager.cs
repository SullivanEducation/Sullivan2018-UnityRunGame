﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public enum GameState
{
    Play,
    Pause,
    End
}

public class GameManager : MonoBehaviour
{
    public static GameState GS;
    

    

    public GameObject pausePanel;

    

    // Use this for initialization
    void Start ()
    {
        GS = GameState.Play;
	}
	
	// Update is called once per frame
	void Update ()
    {
		

        
    }

    public void GetCoin()
    {
        //goldCount++;
        
    }

    public void GameOver()
    {
        
    }

    public void Replay()
    {
        Time.timeScale = 1.0f;
        SceneManager.LoadScene("Scene/Scene01");
        GS = GameState.Play;
        PlayerMovement.goldCount = 0;
        PlayerMovement.meterCount = 0.0f;
    }

    public void MainGo()
    {
        Time.timeScale = 1.0f;
        SceneManager.LoadScene("Scene/Intro");
        GS = GameState.End;
    }

    public void Pause()
    {
        GS = GameState.Pause;
        Time.timeScale = 0.0f;
        pausePanel.SetActive(true);
    }

    public void Resume()
    {
        GS = GameState.Play;
        Time.timeScale = 1.0f;
        pausePanel.SetActive(false);
    }
}
