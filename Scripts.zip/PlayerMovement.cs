﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public enum PlayerState
{
    Run,
    Jump,
    DoubleJump,
    Death
}

public class PlayerMovement : MonoBehaviour
{
    PlayerState PS;
    public float JumpPower = 800.0f;
    public int CoinCount = 0;
    public AudioClip[] Sounds;
    public Animator Anim;
    public GameObject AnotherSpeaker;
    public static bool isGameOver = false;

    public GameManager GM;

    public Text MeterText;
    public Text GoldText;

    public static float meterCount = 0.0f;
    public static int goldCount = 0;
    public static float speed = 10.0f;

    // Use this for initialization
    void Start ()
    {
        GoldText.text = string.Format("0");
    }
	
	// Update is called once per frame
	void Update ()
    {
        if (GameManager.GS == GameState.Play)
        {
            meterCount += Time.deltaTime * speed;

            MeterText.text = string.Format("이동 거리: {0:N0}m", meterCount);

            GoldText.text = string.Format("{0}", goldCount);
        }

        if (Input.GetKeyDown(KeyCode.Space) && PS != PlayerState.Death)
        {
            if(PS == PlayerState.Jump)
            {
                DoubleJump();
            }
            if(PS == PlayerState.Run)
            {
                Jump();
            }
        }
	}

    void Jump()
    {
        PS = PlayerState.Jump;
        GetComponent<Rigidbody>().AddForce(new Vector3(0, JumpPower, 0));
        AnotherSpeaker.SendMessage("PlaySound");
        Anim.SetTrigger("Jump");
        Anim.SetBool("Ground", false);
    }
    void DoubleJump()
    {
        PS = PlayerState.DoubleJump;
        GetComponent<Rigidbody>().AddForce(new Vector3(0, JumpPower, 0));
        AnotherSpeaker.SendMessage("PlaySound");
        Anim.SetTrigger("DoubleJump");
    }
    void Run()
    {
        PS = PlayerState.Run;
        Anim.SetBool("Ground", true);
    }

    void OnCollisionEnter(Collision collision)
    {
        if(PS != PlayerState.Run && PS != PlayerState.Death && collision.gameObject.name != "Coin")
        {
            Anim.SetBool("Ground", true);
            Run();
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        System.GC.Collect();
        GetComponent<Rigidbody>().WakeUp();
        if(other.gameObject.tag == "Coin")
        {
            goldCount++;
            Destroy(other.gameObject);
            SoundPlay(0);
            CoinCount++;
        }
        if(other.gameObject.tag == "Death" && PS != PlayerState.Death)
        {
            isGameOver = true;
            SoundPlay(2);
        }
    }
    void SoundPlay(int num)
    {
        GetComponent<AudioSource>().clip = Sounds[num];
        GetComponent<AudioSource>().Play();
    }
}
