﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BGM : MonoBehaviour
{
    public AudioClip Kalinka;
	// Use this for initialization
	void Start ()
    {
        GetComponent<AudioSource>().clip = Kalinka;
        GetComponent<AudioSource>().Play();
	}
	
	// Update is called once per frame
	void Update () {
		if(PlayerMovement.isGameOver)
        {
            GetComponent<AudioSource>().Stop();
        }
	}
}
