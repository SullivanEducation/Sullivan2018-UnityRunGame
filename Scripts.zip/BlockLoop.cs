﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockLoop : MonoBehaviour {
    public float Speed = 100.0f;
    public GameObject[] AddBlock;
    public GameObject ZoneA;
    public GameObject ZoneB;

	// Use this for initialization
	void Start ()
    {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
        Move();
        if (ZoneB.transform.position.x <= 0.0f)
        {
            Destroy(ZoneA);
            ZoneA = ZoneB;
            Make();
            System.GC.Collect();
        }
	}

    void Move()
    {
        ZoneA.transform.Translate(Vector3.left * Speed * Time.deltaTime);
        ZoneB.transform.Translate(Vector3.left * Speed * Time.deltaTime);
    }

    void Make()
    {
        int Rnd = Random.Range(0, AddBlock.Length);
        //instantiate: 재료(prefab), 좌표, 생성 회전을 이용한 새로운 오브젝터 생성
        ZoneB = Instantiate(AddBlock[Rnd], new Vector3(ZoneA.transform.position.x + 20, -8.0f, 0.0f), transform.rotation);
    }
}
