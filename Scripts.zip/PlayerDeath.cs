﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerDeath : MonoBehaviour {

    public GameObject GameOverObj;
    public float speed = 1.0f;
    public float maxFade = 150.0f;

    public GameObject finalPanel;
    public Text finalMeter;
    public Text finalGold;

    

    // Update is called once per frame
    void Start()
    {
        //GameOverObj = GetComponent<GameObject>(); 
    }
    void Update () {
        if(PlayerMovement.isGameOver)
        {
            GameOver();
            if(GameOverObj.GetComponent<Image>().color.a <= maxFade / 255)
            {
                GameOverObj.GetComponent<Image>().color += new Color(0.0f, 0.0f, 0.0f, speed * Time.deltaTime);
            }
            
        }
	}
    public void GameOver()
    {
        GameOverObj.SetActive(true);
        finalMeter.text = string.Format("Record: {0:N1}m", PlayerMovement.meterCount);
        finalGold.text = string.Format("Coins: {0}", PlayerMovement.goldCount);
        GameManager.GS = GameState.End;
        finalPanel.SetActive(true);
    }
}
