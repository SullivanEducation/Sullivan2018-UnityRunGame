﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraZoom : MonoBehaviour
{
    public Camera mainCamera;
    public GameObject player;
    public float speed = 0.5f;
    float cameraSize = 5.0f;

    public float maxSize = 10.0f;
    public float minSize = 5.0f;
	
	// Update is called once per frame
	void Update ()
    {
        //mainCamera.orthographicSize = 5.0f + player.transform.position.y;
        cameraSize = 5.0f + player.transform.position.y;

        if (cameraSize >= maxSize)
            cameraSize = maxSize;
        if (cameraSize <= minSize)
            cameraSize = minSize;

        //Lerp -> 바꾸기 전 값, 바꿀 값, 바뀔 시간
        mainCamera.orthographicSize = Mathf.Lerp(mainCamera.orthographicSize, cameraSize, Time.deltaTime / speed);
	}
}
